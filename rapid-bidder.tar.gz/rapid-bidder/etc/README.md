# configuration for DSP

