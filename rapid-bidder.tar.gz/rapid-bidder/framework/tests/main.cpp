#define BOOST_TEST_MODULE "vanilla"
#include <boost/test/unit_test.hpp>
