### Diagram of targeting filters used in examples
![alt text](https://raw.githubusercontent.com/wiki/venediktov/vanilla-rtb/images/vanilla-relational-cache-latest.png)
