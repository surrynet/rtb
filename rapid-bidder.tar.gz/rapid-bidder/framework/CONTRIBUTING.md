1. read issues and milestones
2. identify if this issue was already discussed
3. talk to our existing team and find out if anyone is working on this issue
4. If no one in our team is working on the issue:
- fork repository 
- make changes ( make sure your changes have enough comments for us to understand )
- create a pull request referencing issue #
- wait for your pull request review 
5. Done
