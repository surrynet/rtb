/*
 * Copyright (C) Alex Nekipelov (alex@nekipelov.net)
 * License: MIT
 */

#ifndef REDISCLIENT_VERSION_H
#define REDISCLIENT_VERSION_H

#define REDIS_CLIENT_VERSION 10002 // 1.0.2

#endif // REDISCLIENT_VERSION_H
